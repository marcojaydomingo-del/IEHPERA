import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'

export default function Login() {
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const { error } = await signIn(email, password)
    if (error) {
      setError(error.message)
      setLoading(false)
    } else {
      navigate('/')
    }
  }

  return (
    <div style={s.page}>
      <div style={s.card}>
        <div style={s.logo}>
          <div style={s.logoMark}>G</div>
          <div>
            <div style={s.logoName}>Goodnite Sleep Solution</div>
            <div style={s.logoSub}>ERA Financial Dashboard</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} style={s.form}>
          <div style={s.field}>
            <label style={s.label}>Email</label>
            <input
              style={s.input}
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@goodnitesleep.com"
              required
              autoFocus
            />
          </div>
          <div style={s.field}>
            <label style={s.label}>Password</label>
            <input
              style={s.input}
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          {error && <div style={s.error}>{error}</div>}
          <button style={{ ...s.btn, opacity: loading ? 0.7 : 1 }} type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <p style={s.footer}>IEHP ERA data is processed securely in your browser.</p>
      </div>
    </div>
  )
}

const s = {
  page: {
    minHeight: '100vh', display: 'flex', alignItems: 'center',
    justifyContent: 'center', background: '#f8f8f6', padding: '1rem'
  },
  card: {
    background: '#fff', borderRadius: 16, border: '0.5px solid #e0dfd8',
    padding: '2.5rem', width: '100%', maxWidth: 400
  },
  logo: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: '2rem' },
  logoMark: {
    width: 44, height: 44, borderRadius: 12, background: '#1B2A4A',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    color: '#fff', fontSize: 20, fontWeight: 600
  },
  logoName: { fontSize: 15, fontWeight: 600, color: '#1a1a18' },
  logoSub: { fontSize: 12, color: '#888780', marginTop: 2 },
  form: { display: 'flex', flexDirection: 'column', gap: 16 },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { fontSize: 13, fontWeight: 500, color: '#444441' },
  input: {
    padding: '10px 12px', borderRadius: 8, border: '0.5px solid #d3d1c7',
    fontSize: 14, color: '#1a1a18', background: '#fff', outline: 'none',
    transition: 'border-color 0.15s'
  },
  error: {
    fontSize: 13, color: '#A32D2D', background: '#FCEBEB',
    padding: '8px 12px', borderRadius: 8
  },
  btn: {
    marginTop: 8, padding: '11px', borderRadius: 8, border: 'none',
    background: '#1B2A4A', color: '#fff', fontSize: 14, fontWeight: 500,
    cursor: 'pointer', transition: 'opacity 0.15s'
  },
  footer: { marginTop: '1.5rem', fontSize: 11, color: '#b4b2a9', textAlign: 'center' }
}
