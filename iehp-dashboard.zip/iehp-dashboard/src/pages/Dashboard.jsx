import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import Navbar from '../components/Navbar'
import UploadZone from '../components/UploadZone'
import SummaryPanel from '../components/SummaryPanel'
import DeniedPanel from '../components/DeniedPanel'
import PatientTable from '../components/PatientTable'
import ERAHistory from '../components/ERAHistory'
import { Spinner } from '../components/UI'

export default function Dashboard() {
  const { user } = useAuth()
  const [eras, setEras] = useState([])
  const [selectedEra, setSelectedEra] = useState(null)
  const [patients, setPatients] = useState([])
  const [loading, setLoading] = useState(true)
  const [patientsLoading, setPatientsLoading] = useState(false)

  const loadERAs = useCallback(async () => {
    const { data } = await supabase
      .from('eras')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    setEras(data || [])
    if (data && data.length > 0 && !selectedEra) {
      setSelectedEra(data[0])
    }
    setLoading(false)
  }, [user.id])

  useEffect(() => { loadERAs() }, [loadERAs])

  useEffect(() => {
    if (!selectedEra) return
    async function loadPatients() {
      setPatientsLoading(true)
      const { data } = await supabase
        .from('patients')
        .select('*')
        .eq('era_id', selectedEra.id)
        .order('total_billed', { ascending: false })
      setPatients(data || [])

      // Compute LOB counts and update ERA object for charts
      const medCalCount = (data || []).filter(p => p.lob === 'Medi-Cal').length
      const medicareCount = (data || []).filter(p => p.lob === 'Medicare').length
      setSelectedEra(prev => ({ ...prev, medi_cal_count: medCalCount, medicare_count: medicareCount }))
      setPatientsLoading(false)
    }
    loadPatients()
  }, [selectedEra?.id])

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f6' }}>
      <Navbar />

      <div style={s.layout}>
        {/* Sidebar */}
        <aside style={s.sidebar}>
          <UploadZone onUploadComplete={loadERAs} />
          <ERAHistory
            eras={eras}
            selectedId={selectedEra?.id}
            onSelect={era => setSelectedEra(era)}
          />
        </aside>

        {/* Main content */}
        <main style={s.main}>
          {loading ? (
            <div style={s.centered}><Spinner /></div>
          ) : eras.length === 0 ? (
            <EmptyState />
          ) : selectedEra ? (
            <>
              <SummaryPanel era={selectedEra} />
              {patientsLoading ? (
                <div style={s.centered}><Spinner /></div>
              ) : (
                <>
                  <DeniedPanel patients={patients} />
                  <PatientTable patients={patients} eraInfo={selectedEra} />
                </>
              )}
            </>
          ) : null}
        </main>
      </div>
    </div>
  )
}

function EmptyState() {
  return (
    <div style={{ textAlign: 'center', padding: '4rem 2rem' }}>
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d3d1c7" strokeWidth="1.2" style={{ margin: '0 auto 1rem' }}>
        <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
      </svg>
      <div style={{ fontSize: 15, fontWeight: 500, color: '#444441', marginBottom: 8 }}>No ERA files uploaded yet</div>
      <div style={{ fontSize: 13, color: '#888780' }}>Upload an IEHP Remittance Advice PDF to get started</div>
    </div>
  )
}

const s = {
  layout: { maxWidth: 1280, margin: '0 auto', padding: '1.5rem', display: 'grid', gridTemplateColumns: '280px 1fr', gap: '1.5rem', alignItems: 'start' },
  sidebar: { position: 'sticky', top: 72 },
  main: { minWidth: 0 },
  centered: { display: 'flex', justifyContent: 'center', padding: '3rem' },
}
