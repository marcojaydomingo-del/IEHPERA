import { Badge, fmt, Card, SectionHeader } from './UI'

const CODE_STYLES = {
  MISD:  { bg: '#EEEDFE', color: '#534AB7' },
  AUTHD: { bg: '#FAEEDA', color: '#854F0B' },
  EOB:   { bg: '#FCEBEB', color: '#A32D2D' },
  R22:   { bg: '#F1EFE8', color: '#5F5E5A' },
  COBM:  { bg: '#E6F1FB', color: '#185FA5' },
}

export default function DeniedPanel({ patients }) {
  const denied = patients.filter(p => p.is_denied || p.has_partial_denial)
  if (denied.length === 0) return null

  const totalAtRisk = denied.reduce((s, p) => s + (p.total_billed || 0), 0)

  return (
    <Card style={{ marginBottom: '1rem', border: '0.5px solid #f09595' }}>
      <SectionHeader
        title={
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#A32D2D" strokeWidth="2">
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            Denied &amp; unpaid claims — action required
          </span>
        }
        right={
          <span style={{ fontSize: 12, color: '#A32D2D', background: '#FCEBEB', padding: '3px 10px', borderRadius: 6, fontWeight: 500 }}>
            {denied.length} denied · {fmt(totalAtRisk)} at risk
          </span>
        }
      />

      <div style={{ overflowX: 'auto' }}>
        <table style={s.table}>
          <thead>
            <tr style={s.deniedHdr}>
              <th style={{ ...s.th, width: '22%' }}>Patient</th>
              <th style={{ ...s.th, width: '10%' }}>Member #</th>
              <th style={{ ...s.th, width: '10%' }}>Claim #</th>
              <th style={{ ...s.th, width: '8%' }}>Proc(s)</th>
              <th style={{ ...s.th, width: '9%', textAlign: 'right' }}>Billed</th>
              <th style={{ ...s.th, width: '8%' }}>Code</th>
              <th style={{ ...s.th, width: '8%' }}>LOB</th>
              <th style={{ ...s.th, width: '25%' }}>Action needed</th>
            </tr>
          </thead>
          <tbody>
            {denied.map((p, i) => {
              const code = p.denial_codes?.[0] || ''
              const cs = CODE_STYLES[code] || { bg: '#F1EFE8', color: '#5F5E5A' }
              return (
                <tr key={p.id || i} style={{ background: i % 2 === 0 ? '#FFFBF5' : '#fff' }}>
                  <td style={{ ...s.td, fontWeight: 500 }}>{p.name}</td>
                  <td style={{ ...s.td, ...s.mono }}>{p.member_id}</td>
                  <td style={{ ...s.td, ...s.mono }}>{(p.claim_nos || []).join(', ')}</td>
                  <td style={{ ...s.td, color: '#888780' }}>{(p.procs || []).join(', ')}</td>
                  <td style={{ ...s.td, textAlign: 'right', fontWeight: 500 }}>{fmt(p.total_billed)}</td>
                  <td style={s.td}>
                    {p.denial_codes?.map(dc => (
                      <span key={dc} style={{ ...s.codePill, background: cs.bg, color: cs.color }}>{dc}</span>
                    ))}
                  </td>
                  <td style={s.td}>
                    <Badge variant={p.lob === 'Medi-Cal' ? 'blue' : 'purple'}>{p.lob}</Badge>
                  </td>
                  <td style={{ ...s.td, color: '#5F5E5A', fontSize: 11, whiteSpace: 'normal', lineHeight: 1.4 }}>
                    {p.denial_action || '—'}
                    {p.primary_payer && (
                      <div style={{ marginTop: 3, color: '#888780' }}>Primary: {p.primary_payer}</div>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <div style={s.footer}>
        <span style={{ color: '#888780', fontSize: 12 }}>Total at risk</span>
        <span style={{ fontWeight: 500, color: '#A32D2D', fontSize: 13 }}>{fmt(totalAtRisk)}</span>
      </div>
    </Card>
  )
}

const s = {
  table: { width: '100%', borderCollapse: 'collapse', fontSize: 12, tableLayout: 'fixed' },
  deniedHdr: { borderBottom: '0.5px solid #f09595', background: '#FCEBEB' },
  th: { padding: '7px 8px', fontSize: 11, fontWeight: 500, color: '#791F1F', textAlign: 'left' },
  td: { padding: '8px 8px', borderBottom: '0.5px solid #f1efe8', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  mono: { fontFamily: 'monospace', fontSize: 10, color: '#888780' },
  codePill: { display: 'inline-block', padding: '2px 7px', borderRadius: 4, fontSize: 10, fontWeight: 500, marginRight: 3 },
  footer: { marginTop: 10, paddingTop: 10, borderTop: '0.5px solid #e0dfd8', display: 'flex', justifyContent: 'space-between' }
}
