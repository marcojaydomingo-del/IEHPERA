import { useState, useRef } from 'react'
import { extractTextFromPDF, parseERAText } from '../lib/eraParser'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { Spinner } from './UI'

export default function UploadZone({ onUploadComplete }) {
  const { user } = useAuth()
  const [dragging, setDragging] = useState(false)
  const [status, setStatus] = useState('')
  const [progress, setProgress] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const inputRef = useRef()

  async function processFile(file) {
    if (!file || file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file.')
      return
    }
    setLoading(true)
    setError('')
    setProgress(10)

    try {
      setStatus('Reading PDF...')
      const { text, numPages } = await extractTextFromPDF(file)
      setProgress(40)

      setStatus(`Parsing ${numPages} pages...`)
      const era = parseERAText(text, file.name)
      setProgress(65)

      if (era.patients.length === 0) {
        throw new Error('No patient data found. Make sure this is an IEHP Remittance Advice PDF.')
      }

      setStatus('Saving to database...')

      // Save ERA record
      const { data: eraRecord, error: eraErr } = await supabase
        .from('eras')
        .insert({
          user_id: user.id,
          filename: file.name,
          check_date: era.checkDate || null,
          check_no: era.checkNo || null,
          check_amount: era.checkAmount || era.netPaid,
          total_billed: era.totalBilled,
          amount_allowed: era.amountAllowed,
          not_covered: era.notCovered,
          copay_deduct: era.copayDeduct,
          withheld: era.withheld,
          net_paid: era.netPaid,
          total_claims: era.totalClaims || era.patients.length,
          total_claim_lines: era.totalClaimLines,
          provider_name: era.providerName,
          npi: era.npi,
          patient_count: era.patients.length,
          denied_count: era.patients.filter(p => p.isDenied || p.hasPartialDenial).length,
        })
        .select()
        .single()

      if (eraErr) throw eraErr
      setProgress(75)

      // Save patients
      const patientRows = era.patients.map(p => ({
        era_id: eraRecord.id,
        user_id: user.id,
        member_id: p.memberId,
        name: p.name,
        lob: p.lob,
        claim_nos: p.claimNos,
        procs: p.procs,
        total_billed: p.totalBilled,
        total_allowed: p.totalAllowed,
        total_not_covered: p.totalNotCov,
        total_copay_deduct: p.totalCopay + p.totalDeduct,
        total_withhold: p.totalWithhold,
        total_net_paid: p.totalNetPaid,
        is_denied: p.isDenied,
        has_partial_denial: p.hasPartialDenial,
        denial_codes: p.denialCodes,
        denial_action: p.denialAction,
        primary_payer: p.primaryPayer,
        claim_lines: p.claimLines,
      }))

      const { error: patErr } = await supabase
        .from('patients')
        .insert(patientRows)

      if (patErr) throw patErr
      setProgress(100)

      setStatus(`Done! ${era.patients.length} patients loaded.`)
      setTimeout(() => {
        setLoading(false)
        setStatus('')
        setProgress(0)
        onUploadComplete()
      }, 1200)

    } catch (err) {
      setError(err.message || 'Upload failed.')
      setLoading(false)
      setStatus('')
      setProgress(0)
    }
  }

  return (
    <div style={{ marginBottom: '1.5rem' }}>
      <div
        style={{
          ...s.zone,
          borderColor: dragging ? '#378ADD' : '#d3d1c7',
          background: dragging ? '#E6F1FB' : '#fff',
        }}
        onClick={() => !loading && inputRef.current.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => {
          e.preventDefault()
          setDragging(false)
          processFile(e.dataTransfer.files[0])
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".pdf"
          style={{ display: 'none' }}
          onChange={e => processFile(e.target.files[0])}
        />

        {loading ? (
          <div style={s.loadingInner}>
            <Spinner />
            <div style={s.statusText}>{status}</div>
            <div style={s.progressBar}>
              <div style={{ ...s.progressFill, width: progress + '%' }} />
            </div>
          </div>
        ) : (
          <div style={s.idleInner}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#888780" strokeWidth="1.5" style={{ marginBottom: 8 }}>
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
            </svg>
            <div style={s.uploadLabel}>Drop IEHP ERA Remittance PDF here</div>
            <div style={s.uploadSub}>or click to browse · PDF files only · processed securely in browser</div>
          </div>
        )}
      </div>

      {error && (
        <div style={s.error}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ flexShrink: 0 }}>
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          {error}
        </div>
      )}
    </div>
  )
}

const s = {
  zone: {
    border: '1.5px dashed', borderRadius: 12, padding: '1.75rem 1rem',
    textAlign: 'center', cursor: 'pointer', transition: 'all 0.15s',
    minHeight: 130, display: 'flex', alignItems: 'center', justifyContent: 'center'
  },
  idleInner: { display: 'flex', flexDirection: 'column', alignItems: 'center' },
  loadingInner: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, width: '100%', maxWidth: 320 },
  uploadLabel: { fontSize: 14, fontWeight: 500, color: '#444441', marginBottom: 4 },
  uploadSub: { fontSize: 12, color: '#b4b2a9' },
  statusText: { fontSize: 13, color: '#444441' },
  progressBar: { width: '100%', height: 4, background: '#e0dfd8', borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', background: '#1D9E75', borderRadius: 2, transition: 'width 0.3s ease' },
  error: {
    marginTop: 8, fontSize: 12, color: '#A32D2D', background: '#FCEBEB',
    padding: '8px 12px', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 6
  }
}
