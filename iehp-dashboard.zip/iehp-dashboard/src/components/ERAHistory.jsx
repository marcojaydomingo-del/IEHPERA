import { fmt } from './UI'

export default function ERAHistory({ eras, selectedId, onSelect, onDelete }) {
  if (!eras || eras.length === 0) return null

  return (
    <div style={s.wrap}>
      <div style={s.title}>Uploaded ERAs</div>
      {eras.map(era => (
        <div
          key={era.id}
          style={{ ...s.item, ...(selectedId === era.id ? s.itemActive : {}) }}
          onClick={() => onSelect(era)}
        >
          <div style={s.itemTop}>
            <span style={s.itemNo}>{era.check_no || 'ERA'}</span>
            {era.denied_count > 0 && (
              <span style={s.deniedBadge}>{era.denied_count} denied</span>
            )}
          </div>
          <div style={s.itemDate}>{era.check_date || era.filename}</div>
          <div style={s.itemAmt}>{fmt(era.net_paid)}</div>
        </div>
      ))}
    </div>
  )
}

const s = {
  wrap: { marginBottom: '1.25rem' },
  title: { fontSize: 11, fontWeight: 500, color: '#888780', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 },
  item: {
    padding: '10px 12px', borderRadius: 8, border: '0.5px solid #e0dfd8',
    background: '#fff', marginBottom: 6, cursor: 'pointer', transition: 'background 0.1s'
  },
  itemActive: { background: '#E6F1FB', borderColor: '#85B7EB' },
  itemTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 },
  itemNo: { fontSize: 12, fontWeight: 500, color: '#1a1a18' },
  itemDate: { fontSize: 11, color: '#888780', marginBottom: 2 },
  itemAmt: { fontSize: 13, fontWeight: 500, color: '#0F6E56' },
  deniedBadge: { fontSize: 10, padding: '2px 6px', borderRadius: 4, background: '#FCEBEB', color: '#A32D2D', fontWeight: 500 },
}
