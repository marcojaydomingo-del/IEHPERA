import { Doughnut } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip } from 'chart.js'
import { MetricCard, fmt } from './UI'

ChartJS.register(ArcElement, Tooltip)

export default function SummaryPanel({ era }) {
  if (!era) return null

  const deniedCount = era.denied_count || 0
  const patientCount = era.patient_count || 0

  const donutData = {
    labels: ['Net paid', 'Withheld', 'Copay/deduct', 'Not covered'],
    datasets: [{
      data: [era.net_paid, era.withheld, era.copay_deduct, era.not_covered],
      backgroundColor: ['#1D9E75', '#BA7517', '#888780', '#E24B4A'],
      borderWidth: 0,
      hoverOffset: 4,
    }]
  }

  const lobData = {
    labels: ['Medi-Cal', 'Medicare'],
    datasets: [{
      data: [era.medi_cal_count || 0, era.medicare_count || 0],
      backgroundColor: ['#378ADD', '#7F77DD'],
      borderWidth: 0,
      hoverOffset: 4,
    }]
  }

  const donutOpts = {
    responsive: true, maintainAspectRatio: false, cutout: '68%',
    plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + fmt(ctx.parsed) } } }
  }

  const lobOpts = {
    responsive: true, maintainAspectRatio: false, cutout: '68%',
    plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + ctx.parsed + ' patients' } } }
  }

  return (
    <div style={{ marginBottom: '1.25rem' }}>
      {/* ERA info strip */}
      <div style={s.strip}>
        <span style={s.stripItem}><span style={s.stripLabel}>Check</span> {era.check_no || '—'}</span>
        <span style={s.stripItem}><span style={s.stripLabel}>Date</span> {era.check_date || '—'}</span>
        <span style={s.stripItem}><span style={s.stripLabel}>File</span> {era.filename}</span>
        <span style={s.stripItem}><span style={s.stripLabel}>Provider</span> {era.provider_name}</span>
      </div>

      {/* Metric cards */}
      <div style={s.cardGrid}>
        <MetricCard label="Total billed"    value={fmt(era.total_billed)}   color="#185FA5" bg="#E6F1FB" />
        <MetricCard label="Amount allowed"  value={fmt(era.amount_allowed)}  bg="#F1EFE8" />
        <MetricCard label="Net paid"        value={fmt(era.net_paid)}        color="#0F6E56" bg="#E1F5EE" />
        <MetricCard label="Not covered"     value={fmt(era.not_covered)}     color="#A32D2D" bg="#FCEBEB" />
        <MetricCard label="Copay / deduct"  value={fmt(era.copay_deduct)}    color="#854F0B" bg="#FAEEDA" />
        <MetricCard label="Withheld (1%)"   value={fmt(era.withheld)}        bg="#F1EFE8" />
        <MetricCard label="Patients"        value={patientCount}             bg="#F1EFE8" />
        <MetricCard
          label="Denied"
          value={deniedCount}
          color={deniedCount > 0 ? '#A32D2D' : '#0F6E56'}
          bg={deniedCount > 0 ? '#FCEBEB' : '#E1F5EE'}
          sub={deniedCount > 0 ? 'Requires action' : 'No denials'}
        />
      </div>

      {/* Charts row */}
      <div style={s.chartRow}>
        <div style={s.chartCard}>
          <div style={s.chartTitle}>Payment breakdown</div>
          <div style={s.legend}>
            {['Net paid','Withheld','Copay/deduct','Not covered'].map((l, i) => (
              <span key={l} style={s.legendItem}>
                <span style={{ ...s.legendDot, background: ['#1D9E75','#BA7517','#888780','#E24B4A'][i] }} />
                {l}
              </span>
            ))}
          </div>
          <div style={{ height: 160, position: 'relative' }}>
            <Doughnut data={donutData} options={donutOpts} />
          </div>
        </div>

        <div style={s.chartCard}>
          <div style={s.chartTitle}>Line of business</div>
          <div style={s.legend}>
            {['Medi-Cal','Medicare'].map((l, i) => (
              <span key={l} style={s.legendItem}>
                <span style={{ ...s.legendDot, background: ['#378ADD','#7F77DD'][i] }} />
                {l}
              </span>
            ))}
          </div>
          <div style={{ height: 160, position: 'relative' }}>
            <Doughnut data={lobData} options={lobOpts} />
          </div>
        </div>

        <div style={s.statsCard}>
          <div style={s.chartTitle}>Quick stats</div>
          <div style={s.statRow}>
            <span style={s.statLabel}>Payment rate</span>
            <span style={s.statVal}>
              {era.amount_allowed ? ((era.net_paid / era.amount_allowed) * 100).toFixed(1) + '%' : '—'}
            </span>
          </div>
          <div style={s.statRow}>
            <span style={s.statLabel}>Denial rate</span>
            <span style={{ ...s.statVal, color: deniedCount > 0 ? '#A32D2D' : '#0F6E56' }}>
              {patientCount ? ((deniedCount / patientCount) * 100).toFixed(1) + '%' : '—'}
            </span>
          </div>
          <div style={s.statRow}>
            <span style={s.statLabel}>Avg paid / patient</span>
            <span style={s.statVal}>
              {patientCount ? fmt(era.net_paid / patientCount) : '—'}
            </span>
          </div>
          <div style={s.statRow}>
            <span style={s.statLabel}>Total claims</span>
            <span style={s.statVal}>{era.total_claims || '—'}</span>
          </div>
          <div style={s.statRow}>
            <span style={s.statLabel}>Claim lines</span>
            <span style={s.statVal}>{era.total_claim_lines || '—'}</span>
          </div>
          <div style={{ ...s.statRow, borderBottom: 'none' }}>
            <span style={s.statLabel}>Contractual adj</span>
            <span style={s.statVal}>{fmt(era.total_billed - era.amount_allowed)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

const s = {
  strip: {
    display: 'flex', gap: 24, flexWrap: 'wrap', marginBottom: '1rem',
    padding: '8px 0', borderBottom: '0.5px solid #e0dfd8'
  },
  stripItem: { fontSize: 12, color: '#444441' },
  stripLabel: { fontSize: 11, color: '#888780', marginRight: 4 },
  cardGrid: {
    display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))',
    gap: 10, marginBottom: '1rem'
  },
  chartRow: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '1rem' },
  chartCard: {
    background: '#fff', borderRadius: 12, border: '0.5px solid #e0dfd8',
    padding: '1rem 1.25rem'
  },
  statsCard: {
    background: '#fff', borderRadius: 12, border: '0.5px solid #e0dfd8',
    padding: '1rem 1.25rem'
  },
  chartTitle: { fontSize: 12, fontWeight: 500, color: '#1a1a18', marginBottom: 8 },
  legend: { display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  legendItem: { display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#888780' },
  legendDot: { width: 8, height: 8, borderRadius: 2, display: 'inline-block' },
  statRow: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '7px 0', borderBottom: '0.5px solid #f1efe8', fontSize: 12
  },
  statLabel: { color: '#888780' },
  statVal: { fontWeight: 500, color: '#1a1a18' },
}
