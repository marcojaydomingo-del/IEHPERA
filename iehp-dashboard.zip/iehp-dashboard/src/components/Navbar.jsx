import { useAuth } from '../hooks/useAuth'
import { useNavigate } from 'react-router-dom'

export default function Navbar() {
  const { user, signOut } = useAuth()
  const navigate = useNavigate()

  async function handleSignOut() {
    await signOut()
    navigate('/login')
  }

  return (
    <nav style={s.nav}>
      <div style={s.inner}>
        <div style={s.brand}>
          <div style={s.logoMark}>G</div>
          <div>
            <div style={s.logoName}>Goodnite Sleep Solution</div>
            <div style={s.logoSub}>ERA Financial Dashboard</div>
          </div>
        </div>
        <div style={s.right}>
          <span style={s.userEmail}>{user?.email}</span>
          <button style={s.signOutBtn} onClick={handleSignOut}>Sign out</button>
        </div>
      </div>
    </nav>
  )
}

const s = {
  nav: {
    background: '#1B2A4A', borderBottom: '0.5px solid rgba(255,255,255,0.08)',
    position: 'sticky', top: 0, zIndex: 100
  },
  inner: {
    maxWidth: 1280, margin: '0 auto', padding: '0 1.5rem',
    height: 56, display: 'flex', alignItems: 'center', justifyContent: 'space-between'
  },
  brand: { display: 'flex', alignItems: 'center', gap: 10 },
  logoMark: {
    width: 34, height: 34, borderRadius: 8, background: 'rgba(255,255,255,0.12)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    color: '#fff', fontSize: 16, fontWeight: 600
  },
  logoName: { fontSize: 14, fontWeight: 600, color: '#fff' },
  logoSub: { fontSize: 11, color: 'rgba(255,255,255,0.45)', marginTop: 1 },
  right: { display: 'flex', alignItems: 'center', gap: 12 },
  userEmail: { fontSize: 12, color: 'rgba(255,255,255,0.5)' },
  signOutBtn: {
    fontSize: 12, padding: '5px 12px', borderRadius: 6,
    border: '0.5px solid rgba(255,255,255,0.2)', background: 'transparent',
    color: 'rgba(255,255,255,0.7)', cursor: 'pointer'
  }
}
