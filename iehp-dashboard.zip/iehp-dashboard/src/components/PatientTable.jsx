import { useState } from 'react'
import * as XLSX from 'xlsx'
import { Badge, StatusPill, fmt, Card, SectionHeader } from './UI'

export default function PatientTable({ patients, eraInfo }) {
  const [search, setSearch] = useState('')
  const [lobFilter, setLobFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [expanded, setExpanded] = useState(null)
  const [sortField, setSortField] = useState('total_billed')
  const [sortDir, setSortDir] = useState('desc')

  function toggleSort(field) {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortField(field); setSortDir('desc') }
  }

  const filtered = patients
    .filter(p => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false
      if (lobFilter && p.lob !== lobFilter) return false
      if (statusFilter === 'paid' && (p.is_denied || p.has_partial_denial)) return false
      if (statusFilter === 'denied' && !p.is_denied && !p.has_partial_denial) return false
      return true
    })
    .sort((a, b) => {
      const av = a[sortField] || 0, bv = b[sortField] || 0
      return sortDir === 'asc' ? av - bv : bv - av
    })

  function patientStatus(p) {
    if (p.is_denied) return 'D'
    if (p.has_partial_denial) return 'partial'
    return 'P'
  }

  function exportToExcel() {
    const wb = XLSX.utils.book_new()
    const allRows = [
      ['Patient Name','Member #','LOB','Claim #(s)','Proc Codes','Billed','Allowed','Net Paid','Status','Denial Codes','Action'],
      ...patients.map(p => [
        p.name, p.member_id, p.lob,
        (p.claim_nos || []).join(', '),
        (p.procs || []).join(', '),
        p.total_billed, p.total_allowed, p.total_net_paid,
        p.is_denied ? 'Denied' : p.has_partial_denial ? 'Partial' : 'Paid',
        (p.denial_codes || []).join(', '),
        p.denial_action || ''
      ])
    ]
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(allRows), 'All Patients')

    const denied = patients.filter(p => p.is_denied || p.has_partial_denial)
    if (denied.length) {
      const dRows = [
        ['Patient','Member #','Claim #','Proc','Billed','Code','LOB','Action'],
        ...denied.map(p => [
          p.name, p.member_id,
          (p.claim_nos || []).join(', '),
          (p.procs || []).join(', '),
          p.total_billed,
          (p.denial_codes || []).join(', '),
          p.lob, p.denial_action || ''
        ])
      ]
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(dRows), 'Denied Claims')
    }

    const name = eraInfo?.check_no || 'ERA'
    XLSX.writeFile(wb, `IEHP_${name}_patients.xlsx`)
  }

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <span style={{ color: '#d3d1c7', marginLeft: 3 }}>↕</span>
    return <span style={{ color: '#185FA5', marginLeft: 3 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>
  }

  return (
    <Card>
      <SectionHeader
        title="All patients"
        right={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: '#888780' }}>{filtered.length} of {patients.length}</span>
            <button style={s.exportBtn} onClick={exportToExcel}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
              </svg>
              Export Excel
            </button>
          </div>
        }
      />

      <div style={s.controls}>
        <input
          style={s.searchInput}
          type="text"
          placeholder="Search patient name..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select style={s.select} value={lobFilter} onChange={e => setLobFilter(e.target.value)}>
          <option value="">All lines of business</option>
          <option value="Medi-Cal">Medi-Cal</option>
          <option value="Medicare">Medicare</option>
        </select>
        <select style={s.select} value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          <option value="paid">Paid only</option>
          <option value="denied">Denied only</option>
        </select>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={s.table}>
          <thead>
            <tr style={{ borderBottom: '0.5px solid #e0dfd8' }}>
              <th style={{ ...s.th, width: '24%' }}>Patient name</th>
              <th style={{ ...s.th, width: '13%' }}>Member #</th>
              <th style={{ ...s.th, width: '8%' }}>LOB</th>
              <th style={{ ...s.th, width: '9%' }}>Proc(s)</th>
              <th style={{ ...s.th, width: '10%', textAlign: 'right', cursor: 'pointer' }} onClick={() => toggleSort('total_billed')}>
                Billed <SortIcon field="total_billed" />
              </th>
              <th style={{ ...s.th, width: '10%', textAlign: 'right', cursor: 'pointer' }} onClick={() => toggleSort('total_allowed')}>
                Allowed <SortIcon field="total_allowed" />
              </th>
              <th style={{ ...s.th, width: '10%', textAlign: 'right', cursor: 'pointer' }} onClick={() => toggleSort('total_net_paid')}>
                Net paid <SortIcon field="total_net_paid" />
              </th>
              <th style={{ ...s.th, width: '8%' }}>Status</th>
              <th style={{ ...s.th, width: '8%' }}>Denial code</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p, i) => {
              const status = patientStatus(p)
              const isExp = expanded === (p.id || i)
              return [
                <tr
                  key={p.id || i}
                  style={{
                    background: status === 'D' ? '#FFFBF5' : status === 'partial' ? '#FFFDF0' : i % 2 === 0 ? '#fff' : '#fafaf8',
                    cursor: 'pointer'
                  }}
                  onClick={() => setExpanded(isExp ? null : (p.id || i))}
                >
                  <td style={{ ...s.td, fontWeight: 500 }}>
                    <span style={{ marginRight: 6, color: '#b4b2a9', fontSize: 10 }}>{isExp ? '▼' : '▶'}</span>
                    {p.name}
                  </td>
                  <td style={{ ...s.td, ...s.mono }}>{p.member_id}</td>
                  <td style={s.td}><Badge variant={p.lob === 'Medi-Cal' ? 'blue' : 'purple'}>{p.lob === 'Medi-Cal' ? 'Medi-Cal' : 'Medicare'}</Badge></td>
                  <td style={{ ...s.td, color: '#888780' }}>{(p.procs || []).slice(0, 3).join(', ')}{(p.procs || []).length > 3 ? '...' : ''}</td>
                  <td style={{ ...s.td, textAlign: 'right' }}>{fmt(p.total_billed)}</td>
                  <td style={{ ...s.td, textAlign: 'right', color: '#888780' }}>{fmt(p.total_allowed)}</td>
                  <td style={{ ...s.td, textAlign: 'right', fontWeight: 500, color: status === 'D' ? '#A32D2D' : '#0F6E56' }}>
                    {fmt(p.total_net_paid)}
                  </td>
                  <td style={s.td}><StatusPill status={status} /></td>
                  <td style={s.td}>
                    {(p.denial_codes || []).map(dc => (
                      <span key={dc} style={s.codeTag}>{dc}</span>
                    ))}
                  </td>
                </tr>,
                isExp && (
                  <tr key={`exp-${p.id || i}`} style={{ background: '#f8f8f6' }}>
                    <td colSpan={9} style={{ padding: '12px 16px 12px 32px' }}>
                      <div style={s.expandGrid}>
                        <div>
                          <div style={s.expLabel}>Claim numbers</div>
                          <div style={s.expVal}>{(p.claim_nos || []).join(', ') || '—'}</div>
                        </div>
                        <div>
                          <div style={s.expLabel}>Procedure codes</div>
                          <div style={s.expVal}>{(p.procs || []).join(', ') || '—'}</div>
                        </div>
                        <div>
                          <div style={s.expLabel}>Copay / deduct</div>
                          <div style={s.expVal}>{fmt(p.total_copay_deduct)}</div>
                        </div>
                        <div>
                          <div style={s.expLabel}>Withheld</div>
                          <div style={s.expVal}>{fmt(p.total_withhold)}</div>
                        </div>
                        <div>
                          <div style={s.expLabel}>Not covered</div>
                          <div style={s.expVal}>{fmt(p.total_not_covered)}</div>
                        </div>
                        {p.primary_payer && (
                          <div>
                            <div style={s.expLabel}>Primary payer</div>
                            <div style={{ ...s.expVal, color: '#A32D2D' }}>{p.primary_payer}</div>
                          </div>
                        )}
                        {p.denial_action && (
                          <div style={{ gridColumn: '1/-1' }}>
                            <div style={s.expLabel}>Action required</div>
                            <div style={{ ...s.expVal, color: '#854F0B' }}>{p.denial_action}</div>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              ]
            })}
          </tbody>
        </table>
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '2rem', color: '#888780', fontSize: 13 }}>
          No patients match your filters.
        </div>
      )}
    </Card>
  )
}

const s = {
  controls: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: '0.875rem' },
  searchInput: { fontSize: 12, padding: '7px 10px', borderRadius: 7, border: '0.5px solid #d3d1c7', minWidth: 200, background: '#fff', color: '#1a1a18' },
  select: { fontSize: 12, padding: '7px 10px', borderRadius: 7, border: '0.5px solid #d3d1c7', background: '#fff', color: '#1a1a18' },
  exportBtn: {
    fontSize: 12, padding: '6px 12px', borderRadius: 7,
    border: '0.5px solid #d3d1c7', background: '#fff', color: '#444441',
    cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5
  },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: 12, tableLayout: 'fixed' },
  th: { padding: '7px 8px', fontSize: 11, fontWeight: 500, color: '#888780', textAlign: 'left' },
  td: { padding: '9px 8px', borderBottom: '0.5px solid #f1efe8', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  mono: { fontFamily: 'monospace', fontSize: 10, color: '#888780' },
  codeTag: { display: 'inline-block', padding: '1px 6px', borderRadius: 4, fontSize: 10, fontWeight: 500, background: '#FCEBEB', color: '#A32D2D', marginRight: 3 },
  expandGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 },
  expLabel: { fontSize: 10, color: '#888780', marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.04em' },
  expVal: { fontSize: 12, color: '#1a1a18', fontWeight: 500 },
}
