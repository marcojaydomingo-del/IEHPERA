export function Card({ children, style }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 12,
      border: '0.5px solid #e0dfd8', padding: '1rem 1.25rem', ...style
    }}>
      {children}
    </div>
  )
}

export function MetricCard({ label, value, sub, color = '#1a1a18', bg = '#f8f8f6' }) {
  return (
    <div style={{ background: bg, borderRadius: 10, padding: '0.875rem 1rem' }}>
      <div style={{ fontSize: 11, color: '#888780', marginBottom: 5 }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 500, color, lineHeight: 1.2 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: '#b4b2a9', marginTop: 4 }}>{sub}</div>}
    </div>
  )
}

export function Badge({ children, variant = 'gray' }) {
  const variants = {
    gray:   { bg: '#F1EFE8', color: '#5F5E5A' },
    blue:   { bg: '#E6F1FB', color: '#185FA5' },
    green:  { bg: '#E1F5EE', color: '#0F6E56' },
    red:    { bg: '#FCEBEB', color: '#A32D2D' },
    amber:  { bg: '#FAEEDA', color: '#854F0B' },
    purple: { bg: '#EEEDFE', color: '#534AB7' },
  }
  const v = variants[variant] || variants.gray
  return (
    <span style={{
      fontSize: 11, fontWeight: 500, padding: '3px 9px',
      borderRadius: 6, background: v.bg, color: v.color,
      display: 'inline-block', whiteSpace: 'nowrap'
    }}>
      {children}
    </span>
  )
}

export function StatusPill({ status }) {
  if (status === 'D') return <Badge variant="red">Denied</Badge>
  if (status === 'partial') return <Badge variant="amber">Partial</Badge>
  return <Badge variant="green">Paid</Badge>
}

export function SectionHeader({ title, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.875rem', flexWrap: 'wrap', gap: 8 }}>
      <span style={{ fontSize: 13, fontWeight: 500, color: '#1a1a18' }}>{title}</span>
      {right}
    </div>
  )
}

export function fmt(n) {
  return '$' + (parseFloat(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

export function Spinner() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#888780', fontSize: 13 }}>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83">
          <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/>
        </path>
      </svg>
      Processing...
    </div>
  )
}
